package com.musicalcoder.inspireme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

//import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @OnClick({R.id.register_btn, R.id.login_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_btn:
                Intent registerIntent = new Intent(this, UserRegistration.class);
                startActivity(registerIntent);
                finish();

            case R.id.login_btn:
                Intent loginIntent = new Intent(this, UserLogin.class);
                startActivity(loginIntent);
                finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);
    }
}
